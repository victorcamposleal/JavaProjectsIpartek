
/**
 * Definir una interfaz IConducible con los m�todos arrancar y parar Crear clase
 * Vehiculo ( color, matricula ) para el Coche ( marca, modelo, potencia,
 * cilindrada) Realizar un Diagrama de Clases
 */

package mf0227.uf2404.actividad2;